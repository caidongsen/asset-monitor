#ifndef _KERNEL_TEST_H_
#define _KERNEL_TEST_H_

extern int testSSE();

#endif
